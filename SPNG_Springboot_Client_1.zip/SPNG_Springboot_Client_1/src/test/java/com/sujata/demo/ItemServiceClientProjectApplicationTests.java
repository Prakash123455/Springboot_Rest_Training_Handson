package com.sujata.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemServiceClientProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
