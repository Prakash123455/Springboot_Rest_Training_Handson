package com.synechron.proc.boot.service;

import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.synechron.proc.boot.model.Customer;
import com.synechron.proc.boot.repo.CustomerDao;



@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao customerDao;
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Customer> getAllCustomer() {
		
		return customerDao.findAll();
	}

	@Override
	@SuppressWarnings("unchecked")
	public boolean addCustomer(Customer customer) {
		Customer it=customerDao.save(customer);
		return it!=null;
		
		
	}

	@Override
	@SuppressWarnings("unchecked")
	public boolean deleteCustomer(int id) {
		customerDao.deleteById( id);
		return true;
	}

	@Override
	@SuppressWarnings("unchecked")
	public boolean updateCustomer(int id, Customer newCustomer) {

		customerDao.updateName(id, newCustomer.getCustomerName());
		return true;
	}

	
	@Override
	@SuppressWarnings("unchecked")
	public Customer getCustomer(int id) {
		// TODO Auto-generated method stub
		return customerDao.findById(id).get();
	}

	@Override
	@SuppressWarnings("unchecked")
	public Void getCustomerSalarySlip(int id) {
		Customer cs=customerDao.findById(id).get();
		int GrossSalary=cs.getCustomerSalary();
		
		System.out.println("Basic Salary "+GrossSalary/2);
		System.out.println("House Rent "+GrossSalary/4);
		System.out.println("Professional Allowance "+GrossSalary/6);
		System.out.println("Leave Allowance  "+GrossSalary/4);
		return null;
	}

}
