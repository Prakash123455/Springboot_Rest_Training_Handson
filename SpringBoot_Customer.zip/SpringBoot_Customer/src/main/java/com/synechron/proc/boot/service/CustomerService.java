package com.synechron.proc.boot.service;

import java.util.List;
import java.util.Optional;

import com.synechron.proc.boot.model.Customer;

public interface CustomerService {
	
	
	public List<Customer> getAllCustomer();
	public boolean addCustomer(Customer customer);
	public boolean deleteCustomer(int id);
	public boolean updateCustomer(int id,Customer newCustomer);
	public Customer getCustomer(int id);
	public Void getCustomerSalarySlip(int id);
	
}
